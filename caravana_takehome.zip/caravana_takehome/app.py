import shutil
import time

from flask import Flask, render_template, request, flash, redirect
from flask_caching import Cache
from werkzeug.utils import secure_filename

import data_worker.basefile as basefile
import data_worker.filter_results as filterresults

cache = Cache(config={'CACHE_TYPE': 'SimpleCache'})
UPLOAD_FOLDER = '.'
ALLOWED_EXTENSIONS = {'csv', 'txt'}

app = Flask(__name__)
app.secret_key = 'C@r7@N@K3Y'

cache.init_app(app)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


def read_input_files(locations_f=None, trips_f=None):
    return basefile.main_function(locations_f, trips_f)


def move_file(filename):
    src = f"./{filename}"
    dest = f"./data_worker/uploads/{filename}"
    shutil.move(src, dest)


@app.before_first_request
def before_first_request():
    global input_information
    input_information = read_input_files()
    app.logger.info("before_first_request")


@app.route("/", methods=['GET'])
@app.route('/home', methods=['GET'])
@cache.cached(timeout=50)
def home():
    if request.method == "GET":
        return render_template('home.html')


@app.route('/extract', methods=['POST'])
def extract():
    location_codes = request.form['locationcodes']
    str_results = ""
    if request.method == "POST":
        location_codes = [loc.upper() for loc in location_codes.strip().split(",")]
        str_results = filterresults.filter_results(location_codes, input_information)
    return render_template('extract.html', loc_codes=location_codes, results=str_results)


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        trips_f = request.files['tripsfile']
        locations_f = request.files['locationsfile']
        if not trips_f and not locations_f:
            flash('No selected file')
            return redirect(request.url)
        epoch_time = str(int(time.time()))
        trips_file_path, locations_file_path = None, None
        if trips_f:
            trips_file_name = trips_f.filename
            file_extension = trips_file_name.split(".")[-1]
            trips_file_name = trips_file_name.split(".")
            trips_file_name = "".join(trips_file_name[:-1]) + f"_{epoch_time}." + file_extension
            if file_extension in ALLOWED_EXTENSIONS:
                trips_f.save(secure_filename(trips_file_name))
                trips_file_path = trips_file_name
                print("Files saved")
            else:
                print(f"Received a different file extension - {file_extension}")
        else:
            flash('No selected file')
        if locations_f:
            locations_file_name = locations_f.filename
            file_extension = locations_file_name.split(".")[-1]
            locations_file_name = locations_file_name.split(".")
            locations_file_name = "".join(locations_file_name[:-1]) + f"_{epoch_time}." + file_extension
            if file_extension in ALLOWED_EXTENSIONS:
                locations_f.save(secure_filename(locations_file_name))
                locations_file_path = locations_file_name
                print("Files saved")
            else:
                print(f"Received a different file extension - {file_extension}")
        else:
            flash('No selected file')
        global input_information
        input_information = read_input_files(locations_file_path, trips_file_path)
        move_file(locations_file_path)
        move_file(trips_file_path)
        return redirect("home")
    else:
        return render_template('upload.html')


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5555, debug=True)
