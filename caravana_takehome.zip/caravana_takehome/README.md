Carvana - Take Home Assignment - Raviteja Ainampudi
-

**Technology Stack Used:**

For API Development

* Python3.9
* Flask

For UI Work:

* HTML
* Jinja2

App Deployment:

* Docker
* AWS (EC2)
------------------------------------------------------
Temporarily hosted the API in AWS.  
DNS endpoint to test the API - 


--------------------------------------------------
**Local Deployment Steps:**  
**Procedure 1**:
(Through Docker - _**Recommended**_)  
To build the app docker image:  
`docker build -t carvana-app:latest .`

To deploy the app in docker:  
`docker run -d -p 5555:5555 carvana-app`

OR

**Procedure 2:**
(Direct deployment)  
`chmod u+x app.py `  
`pip install -r requirements.txt`  
`python3 app.py `
------------------------------------------------------
**Usage Process:**

1) Enter the location code to extract the results as desired
2) The results' webpage has the option to return to home
3) You can also pass multiple location codes simultaneously. Comma separated and no space.
4) If consumer is interested in passing custom CSV files, they can UPLOAD the csv files using the Upload hyperlink
   available in the homepage. 
5) And validate the updated results
6) Consumer has ability to reload the primary input any time from the home page

--------------------------------------------------------
**Added features:**
* API has capability for simple caching for 300 seconds
* AWS EC2 has Inbound opened only for 5555 port for public access and outbound is for all ports on internet.
* Test Suite has series of unit tests available for the base functionality of the API. 
* Results can be evaluated in **results.pdf** 
