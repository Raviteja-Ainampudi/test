import traceback

import pandas as pd


class CaravanaLocationsTrips(object):
    """Class used to handle the Locations and Trips"""

    def __init__(self, locations_path=None, trips_path=None):
        if not locations_path:
            self.locations_path = "data_worker/locations.csv"
        else:
            self.locations_path = locations_path

        if not trips_path:
            self.trips_path = "data_worker/trips.csv"
        else:
            self.trips_path = trips_path

    def load_locations(self):
        locations_dict = dict()
        df_locations = pd.read_csv(self.locations_path)
        for index, row in df_locations.iterrows():
            locations_dict[row["LocationCode"].upper()] = {"Long": row["Longitude"],
                                                           "Lat": row["Latitude"],
                                                           "CarvanaOwns": "Owned by Carvana" if row[
                                                               "FacilityOwnedByCarvana"] else "NOT owned by Caravana"}
        return locations_dict

    def load_trips(self):
        df_trips = pd.read_csv(self.trips_path)
        origin_trips = dict()
        destination_trips = dict()
        for index, row in df_trips.iterrows():
            origin = row["Origin"].upper()
            destination = row["Destination"].upper()
            weekly_capacity = int(row["WeeklyCapacity"])
            if origin in origin_trips:
                if destination in origin_trips[origin]:
                    origin_trips[origin][destination]["WeeklyCapacity"] += weekly_capacity
                else:
                    origin_trips[origin][destination] = {"WeeklyCapacity": weekly_capacity}
            else:
                origin_trips[origin] = {destination: {"WeeklyCapacity": weekly_capacity}}

            if destination in destination_trips:
                if origin in destination_trips[destination]:
                    destination_trips[destination][origin]["WeeklyCapacity"] += weekly_capacity
                else:
                    destination_trips[destination][origin] = {"WeeklyCapacity": weekly_capacity}
            else:
                destination_trips[destination] = {origin: {"WeeklyCapacity": weekly_capacity}}
        return origin_trips, destination_trips


def main_function(locations_file=None, trips_file=None) -> dict:
    try:
        od_object = CaravanaLocationsTrips(locations_file, trips_file)
        location_info = od_object.load_locations()
        origin_trips_data, destination_trips_data = od_object.load_trips()
        return {"location_info": location_info,
                "origin_trips_data": origin_trips_data,
                "destination_trips_data": destination_trips_data}
    except Exception as main_func_error:
        print(f"Error while handling the main function in basefile = {main_func_error}")
        errors_all = traceback.format_exc()
        errors_all_list = [error_line.strip() for error_line in errors_all.split("\n") if error_line]
        print(errors_all_list)
        return {}


if __name__ == "__main__":
    print(main_function()["location_info"])
